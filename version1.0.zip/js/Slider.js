 function id(name) {return document.getElementById(name);}
    //遍历函数
    function each(arr, callback) {
        if (arr.forEach) {arr.forEach(callback);} 
        else {  for (var i = 0, len = arr.length; i < len; i++) callback.call(this, arr[i], i, arr);}
    }
    function fadeIn(elem) {
        setOpacity(elem, 0)
        for ( var i = 0; i < 20; i++) {
            (function() {
                var pos = i * 5;
                setTimeout(function() {
                    setOpacity(elem, pos)
                }, i * 25);
            })(i);
        }
    }
    function fadeOut(elem) {
        for ( var i = 0; i <= 20; i++) {
            (function() {
                var pos = 100 - i * 5;
                setTimeout(function() {
                    setOpacity(elem, pos)
                }, i * 25);
            })(i);
        }
    }
    // 设置透明度
    function setOpacity(elem, level) {
        if (elem.filters) {
            elem.style.filter = "alpha(opacity=" + level + ")";
        } else {
            elem.style.opacity = level / 100;
        }
    }